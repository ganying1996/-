package com.lvyou.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.lvyou.bean.Comment;
import com.lvyou.dao.CommentDAO;
import com.lvyou.util.DBConnection;
import com.lvyou.util.Page;

public class CommentDAOImpl implements CommentDAO{

	@Override
	public void addComment(Comment comment) {
		Connection conn=DBConnection.getConnection();		//��ȡ���ݿ����Ӷ���
		String addSQL="insert into comment(activity_id,user1_id,date,content,status) values(?,?,?,?,?)";
		PreparedStatement pstmt=null;
		try{
			pstmt=conn.prepareStatement(addSQL);		//���Ԥ�������󲢸�ֵ
			pstmt.setInt(1, comment.getActivity_id());
			pstmt.setString(2, comment.getUser1_id());
			pstmt.setString(3, comment.getDate());
			pstmt.setString(4, comment.getContent());
			pstmt.setInt(5, comment.getStatus());
			
			pstmt.executeUpdate();						//ִ�и���
			
		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			DBConnection.close(pstmt);
			DBConnection.close(conn);
			
		}
	}

	@Override
	public int queryCommentCount(int activity_id) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Comment> queryByPage(int activity_id, Page page) {
		// TODO Auto-generated method stub
		return null;
	}
//	public static void main(String[] args){
//		Comment comment=new Comment();
//		new CommentDAOImpl().addComment(comment);
//	}

}
