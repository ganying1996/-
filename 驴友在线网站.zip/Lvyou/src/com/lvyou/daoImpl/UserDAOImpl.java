package com.lvyou.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.lvyou.bean.User;
import com.lvyou.dao.UserDAO;
import com.lvyou.util.DBConnection;


public class UserDAOImpl implements UserDAO {

	@Override
	public void updateUserById(String id) {
		Connection conn = DBConnection.getConnection();	//������Ӷ���
		String SQL="update user set rel_Score=rel_Score+2";
		PreparedStatement pstmt = null;					//����Ԥ��������
		try{
			pstmt = conn.prepareStatement(SQL);
			pstmt.executeUpdate();
		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			DBConnection.close(pstmt);
			DBConnection.close(conn);
		}
		
	}

	@Override
	public List<User> findUserByRel() {
		Connection conn = DBConnection.getConnection();	//������Ӷ���
		String SQL="select * from user "+" order by id desc";
		PreparedStatement pstmt = null;					//����Ԥ��������
		ResultSet rs = null;
		List<User> users=new ArrayList<User>();
		try{
			pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();	
			while(rs.next()) {
				User user=new User();
				user.setId(rs.getString(1));
				user.setPassword(rs.getString(2));
				user.setSex(rs.getString(3));
				user.setRel_score(rs.getInt(4));
				user.setPar_score(rs.getInt(5));
				user.setSum_score(rs.getInt(6));
				users.add(user);
			}
		}catch (SQLException e) {
			e.printStackTrace();
		} finally{
			DBConnection.close(rs);								//�رս��������
			DBConnection.close(pstmt);							//�ر�Ԥ��������
			DBConnection.close(conn);							//�ر����Ӷ���
		}
		return users;
	}

	@Override
	public List<User> findUserByPar() {
		// TODO Auto-generated method stub
		return null;
	}
//	public static void main(String[] args){
//		new UserDAOImpl().findUserById("333");
//		System.out.print("�ɹ���");
//	}
	
	private Connection conn=null;//�������ݿ����Ӷ���   
    private PreparedStatement pstmt=null;//�������ݿ��������  
    public void UserDAOImpI(Connection conn){ //�������ݿ�����  
        this.conn=conn;  
    }
    
    @Override
    public boolean findLogin(User user) throws Exception {  
        boolean flag=false;  
        try {  
            String sql="select name from user where name=? and password=?";  
            pstmt=conn.prepareStatement(sql);//ʵ��������  
            pstmt.setString(1,user.getId());  
            pstmt.setString(2, user.getPassword());  
            ResultSet rSet=pstmt.executeQuery();//ȡ�ý��   
            if(rSet.next()){  
                user.setId(rSet.getString(1));//ȡ���û���Id  
                flag=true;        
            }  
  
        } catch (Exception e) {  
            throw e;  
        }finally{  
            //�رղ���  
            if(pstmt!=null){  
                try {  
                    pstmt.close();  
                } catch (Exception e) {  
                    throw e;                  
            }         
        }  
              
        }  
        return flag;  
    }  

}
