package com.lvyou.daoImpl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.lvyou.bean.User;
import com.lvyou.util.DBConnection;


public class UserDao {
	public static List<User> get(){
		
		List<User> list = new ArrayList<User>();
		 
		Connection connection = null;
		 
		ResultSet rs = null;
		DBConnection db = new DBConnection();
		try {
	 
			connection =  db.getConnection();
			
			String sql = "SELECT * FROM user ";
			Statement stmt  = connection.createStatement();
			rs = (ResultSet) stmt.executeQuery(sql);
			while(rs.next()){
				String id = rs.getString("id");
				String password = rs.getString("password");
				String sex = rs.getString("sex");
				int rel_score = rs.getInt("rel_score");
				int par_score = rs.getInt("par_score");
				int sum_score = rs.getInt("sum_score");
				 
				User user = new User(id, password, sex, rel_score, par_score,
						sum_score);
				list.add(user);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally{
			try {
				if(rs!=null) {
					rs.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			 
			try {
				if(connection!=null) {
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
			
		return list;
	}
	public User findID(String id) {
		 
		Connection connection = null;
		 
		ResultSet rs = null;
		DBConnection db = new DBConnection();
		try {
	 
			connection =  db.getConnection();
			
			String sql = "SELECT * FROM user where id='"+id+"'";
			Statement stmt  = connection.createStatement();
			rs = (ResultSet) stmt.executeQuery(sql);
			if(rs.next()){
				String id1 = rs.getString("id");
				String password = rs.getString("password");
				String sex = rs.getString("sex");
				int rel_score = rs.getInt("rel_score");
				int par_score = rs.getInt("par_score");
				int sum_score = rs.getInt("sum_score");
				 
				User user = new User(id1, password, sex, rel_score, par_score,
						sum_score);
				return user;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	public static void main(String args[]) {
		/*ArrayList<Activity> list = (ArrayList<Activity>) new ActivityDao().get();
		for(Activity e:list) {
			System.out.println(e.getPlace());
		}*/
//		System.out.println(new ActivityDao().findTitle("��;"));
	}
}
