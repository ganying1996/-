package com.lvyou.daoImpl;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import com.lvyou.bean.Fabu;
import com.lvyou.util.DBConnection;


public class FabuDao {

public static List<Fabu> get(){
		
		List<Fabu> list = new ArrayList<Fabu>();
		 
		Connection connection = null;
		 
		ResultSet rs = null;
		DBConnection db = new DBConnection();
		try {
	 
			connection =  db.getConnection();
			
			String sql = "SELECT * FROM fabu ";
			Statement stmt  = connection.createStatement();
			  rs = (ResultSet) stmt.executeQuery(sql);
			while(rs.next()){
				String id = rs.getString("id");
				String title = rs.getString("title");
				String content = rs.getString("content");
				int sign = rs.getInt("sign");
				String fdate = rs.getString("fdate");
				
				Fabu fabu = new Fabu(id, title, content, sign,fdate);
				list.add(fabu);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally{
			try {
				if(rs!=null) {
					rs.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			 
			try {
				if(connection!=null) {
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
			
		return list;
	}
	public ArrayList<Fabu> find(String id) {
		ArrayList<Fabu> fabulist=new ArrayList<Fabu>();
		Connection connection = null;
		ResultSet rs = null;
		DBConnection db = new DBConnection();
		try {
	 
			connection =  db.getConnection();
			
			String sql = "SELECT * FROM fabu where id='"+id+"'";
			Statement stmt  = connection.createStatement();
			rs = (ResultSet) stmt.executeQuery(sql);
			while(rs.next()){
				String id1 = rs.getString("id");
				String title = rs.getString("title");
				String content = rs.getString("content");
				int sign = rs.getInt("sign");
				String fdate = rs.getString("fdate");			 
				Fabu fabu = new Fabu(id1, title, content, sign,fdate);
				fabulist.add(fabu);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return fabulist;

	}
		public static void main(String args[]) {
			/*ArrayList<Activity> list = (ArrayList<Activity>) new ActivityDao().get();
			for(Activity e:list) {
				System.out.println(e.getPlace());
			}*/
//			System.out.println(new ActivityDao().findTitle("��;"));
		}
}


