package com.lvyou.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import com.lvyou.bean.Comment;
import com.lvyou.util.DBConnection;

import java.util.ArrayList;
import java.util.List;


public class CommentDao {

	public static List<Comment> get(){
		
		List<Comment> list = new ArrayList<Comment>();
		 
		Connection connection = null;
		 
		ResultSet rs = null;
		DBConnection db = new DBConnection();
		try {
	 
			connection =  db.getConnection();
			
			String sql = "SELECT * FROM comment ";
			Statement stmt  = connection.createStatement();
			  rs = (ResultSet) stmt.executeQuery(sql);
			while(rs.next()){
				int id = rs.getInt("id");
				int activity_id = rs.getInt("activity_id");
				String user1_id = rs.getString("user1_id");
				int status = rs.getInt("status");
				String date = rs.getString("date");
				String content = rs.getString("content");
				
				Comment comment = new Comment(id, activity_id, user1_id, status,date, content);
				list.add(comment);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally{
			try {
				if(rs!=null) {
					rs.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			 
			try {
				if(connection!=null) {
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
			
		return list;
	}
	public ArrayList<Comment> find(String id) {
		ArrayList<Comment> commentlist=new ArrayList<Comment>();
		Connection connection = null;
		ResultSet rs = null;
		DBConnection db = new DBConnection();
		try {
	 
			connection =  db.getConnection();
			
			String sql = "SELECT * FROM comment where activity_id='"+id+"'";
			Statement stmt  = connection.createStatement();
			rs = (ResultSet) stmt.executeQuery(sql);
			while(rs.next()){
				int id1 = rs.getInt("id");
				int activity_id = rs.getInt("activity_id");
				String user1_id = rs.getString("user1_id");
				int status = rs.getInt("status");
				String date = rs.getString("date");
				String content = rs.getString("content");			 
				Comment comment = new Comment(id1, activity_id, user1_id, status,date, content);
				commentlist.add(comment);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return commentlist;

	}
	
	public void setComment(Comment comment) {
		Connection conn=DBConnection.getConnection();		//������Ӷ���
		String addSQL="insert into comment(Activity_id,User1_id,Date,Content,Status) values(?,?,?,?,?)";
		PreparedStatement pstmt=null;						//����Ԥ��������
		
		try{
			pstmt=conn.prepareStatement(addSQL);
			pstmt.setInt(1, comment.getActivity_id());			
			pstmt.setString(2, comment.getUser1_id());			
			pstmt.setString(3, comment.getDate());			
			pstmt.setString(4, comment.getContent());
			pstmt.setInt(5, comment.getStatus());
			pstmt.executeUpdate();		
		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			DBConnection.close(pstmt);					
			DBConnection.close(conn);					
		}
	}
	public static void main(String args[]) {
		/*ArrayList<Activity> list = (ArrayList<Activity>) new ActivityDao().get();
		for(Activity e:list) {
			System.out.println(e.getPlace());
		}*/
//		System.out.println(new ActivityDao().findTitle("��;"));
	}
}
