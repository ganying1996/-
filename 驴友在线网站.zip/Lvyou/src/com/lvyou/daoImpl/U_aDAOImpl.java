package com.lvyou.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.lvyou.bean.U_a;
import com.lvyou.dao.U_aDAO;
import com.lvyou.util.DBConnection;

public class U_aDAOImpl implements U_aDAO{

	@Override
	public void addFabu(U_a a) {
		Connection conn=DBConnection.getConnection();		//������Ӷ���
		String SQL="insert into u_a(user2_id,activity1_id,sign,fdate) values(?,?,?,?)";
		PreparedStatement pstmt=null;						//����Ԥ��������
		try{
			pstmt=conn.prepareStatement(SQL);				//��ȡԤ�������󲢸�ֵ
			pstmt.setString(1, a.getUser2_id());
			pstmt.setInt(2, a.getActivity1_id());
			pstmt.setInt(3, a.getSign());
			pstmt.setString(4, a.getFdate());
			pstmt.executeUpdate();							//ִ�и���
		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			DBConnection.close(pstmt);
			DBConnection.close(conn);
		}
		
	}

	@Override
	public void addCanjia(U_a a) {
		// TODO Auto-generated method stub
		
	}
	public static void main(String[] args){
		U_a a=new U_a();
		new U_aDAOImpl().addFabu(a);
	}

}
