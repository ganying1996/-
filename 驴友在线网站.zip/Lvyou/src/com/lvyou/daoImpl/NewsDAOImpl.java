package com.lvyou.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.lvyou.bean.Activity;
import com.lvyou.bean.News;
import com.lvyou.dao.NewsDAO;
import com.lvyou.util.DBConnection;

public class NewsDAOImpl implements NewsDAO{

	@Override
	public void addNews(News news) {
		Connection conn=DBConnection.getConnection();		//������Ӷ���
		String addSQL="insert into news(admin_id,date,content,title) values(?,?,?,?)";
		PreparedStatement pstmt=null;						//����Ԥ��������
		try{
			pstmt=conn.prepareStatement(addSQL);			//��ȡԤ�������󲢸�ֵ
			pstmt.setString(1, news.getAdmin_id());			//���õ�һ������
			pstmt.setString(2, news.getDate());			//���õڶ�������
			pstmt.setString(3, news.getContent());			//���õ���������
			pstmt.setString(4, news.getTitle());				//���õ��ĸ�����
			pstmt.executeUpdate();							//ִ�и���
		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			DBConnection.close(pstmt);						//�ر�Ԥ����
			DBConnection.close(conn);						//�ر�����
		}
		
		
	}

	@Override
	public List<News> findAllNews() {
		// TODO Auto-generated method stub
		return null;
	}
	public static void main(String[] args){
		News news=new News();
		news=new NewsDAOImpl().findNews();
		System.out.print(news.getContent());
		System.out.print(news.getTitle());
	}

	@Override
	public News findNews() {
		Connection conn=DBConnection.getConnection();		//������Ӷ���
		String SQL="select * from news "+"order by id desc";
		PreparedStatement pstmt = null;					//����Ԥ��������
		ResultSet rs = null;
		List<News> news=new ArrayList<News>();
		News ns=new News();
		try{
			pstmt=conn.prepareStatement(SQL);
			rs=pstmt.executeQuery();				//ִ�в�ѯ
			while(rs.next()){
				News n=new News();
				n.setId(rs.getInt(1));
				n.setAdmin_id(rs.getString(2));
				n.setDate(rs.getString(3));
				n.setContent(rs.getString(4));
				n.setTitle(rs.getString(5));
				news.add(n);
			}
		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			DBConnection.close(rs);
			DBConnection.close(pstmt);
			DBConnection.close(conn);
		}
		ns=news.get(0);
		return ns;
	}

}
