package com.lvyou.daoImpl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.lvyou.bean.Activity;
import com.lvyou.util.DBConnection;

import java.util.ArrayList;
import java.util.List;

public class ActivityDao {

	public static List<Activity> get(){
		
		List<Activity> list = new ArrayList<Activity>();
		 
		Connection connection = null;
		 
		ResultSet rs = null;
		DBConnection db = new DBConnection();
		try {
	 
			connection =  db.getConnection();
			
			String sql = "SELECT * FROM activity ";
			Statement stmt  = connection.createStatement();
			  rs = (ResultSet) stmt.executeQuery(sql);
			while(rs.next()){
				int id = rs.getInt("id");
				String user_id = rs.getString("user_id");
				String title = rs.getString("title");
				String date = rs.getString("date");
				String place = rs.getString("place");
				String content = rs.getString("content");
				int act_heat = rs.getInt("act_heat");
				String tel = rs.getString("tel");
				 
				Activity activity = new Activity(id, user_id, act_heat, date, place,
						content, title,tel);
				list.add(activity);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally{
			try {
				if(rs!=null) {
					rs.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			 
			try {
				if(connection!=null) {
					connection.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
			
		return list;
	}
	public Activity findID(String id) {
		 
		Connection connection = null;
		 
		ResultSet rs = null;
		DBConnection db = new DBConnection();
		try {
	 
			connection =  db.getConnection();
			
			String sql = "SELECT * FROM activity where id='"+id+"'";
			Statement stmt  = connection.createStatement();
			  rs = (ResultSet) stmt.executeQuery(sql);
			if(rs.next()){
				int id1 = rs.getInt("id");
				String user_id = rs.getString("user_id");
				String titles = rs.getString("title");
				String date = rs.getString("date");
				String place = rs.getString("place");
				String content = rs.getString("content");
				int act_heat = rs.getInt("act_heat");
				String tel = rs.getString("tel");
				 
				Activity activity = new Activity(id1, user_id, act_heat, date, place,
						content, titles,tel);
				return activity;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
	public static void main(String args[]) {
		/*ArrayList<Activity> list = (ArrayList<Activity>) new ActivityDao().get();
		for(Activity e:list) {
			System.out.println(e.getPlace());
		}*/
//		System.out.println(new ActivityDao().findTitle("��;"));
	}
	 
}
