package com.lvyou.bean;

import java.util.Date;

public class Answer {
	private int id;
	private int com_id;
	private String user3_id;
	private String activity2_id;
	private String content;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getCom_id() {
		return com_id;
	}
	public void setCom_id(int com_id) {
		this.com_id = com_id;
	}
	public String getUser3_id() {
		return user3_id;
	}
	public void setUser3_id(String user3_id) {
		this.user3_id = user3_id;
	}
	public String getActivity2_id() {
		return activity2_id;
	}
	public void setActivity2_id(String activity2_id) {
		this.activity2_id = activity2_id;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	private Date date;

}
