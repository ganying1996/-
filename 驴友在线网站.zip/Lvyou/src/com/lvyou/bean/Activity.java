package com.lvyou.bean;

import java.util.Date;

public class Activity {
	private int id;
	private String user_id;
	private int act_heat;
	private String date;
	private String place;
	private String content;
	private String title;
	private String tel;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public int getAct_heat() {
		return act_heat;
	}
	public void setAct_heat(int act_heat) {
		this.act_heat = act_heat;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	
	public Activity(int id,String user_id,int act_heat,String date,String place,
			String content,String title,String tel){
		super();
		this.id =id;
		this.user_id=user_id;
		this.act_heat=act_heat;
		this.date=date;
		this.place=place;
		this.content=content;
		this.title=title;
		this.tel =tel;
	}
	
	public Activity() {
		
	}
	

}
