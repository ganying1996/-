package com.lvyou.bean;

public class Comment {
	private int id;
	private int activity_id;
	private String user1_id;
	private int status;
	private String date;
	private String content;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getActivity_id() {
		return activity_id;
	}
	public void setActivity_id(int activity_id) {
		this.activity_id = activity_id;
	}
	public String getUser1_id() {
		return user1_id;
	}
	public void setUser1_id(String user1_id) {
		this.user1_id = user1_id;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	
	public Comment(int id,int activity_id,String user1_id,int status,
			String date,String content){
		super();
		this.id=id;
		this.activity_id=activity_id;
		this.user1_id=user1_id;
		this.status=status;
		this.date=date;
		this.content=content;
	}
	public Comment() {
		
	}

}
