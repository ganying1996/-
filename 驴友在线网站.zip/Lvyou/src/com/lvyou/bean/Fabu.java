package com.lvyou.bean;

public class Fabu {
		private String id;
		private String title;
		private String content;
		private int sign;
		private String fdate;
		
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getTitle() {
			return title;
		}
		public void setTitle(String title) {
			this.title = title;
		}
		public String getContent() {
			return content;
		}
		public void setContent(String content) {
			this.content = content;
		}
		public int getSign() {
			return sign;
		}
		public void setSign(int sign) {
			this.sign = sign;
		}
		public String getFdate() {
			return fdate;
		}
		public void setFdate(String fdate) {
			this.fdate = fdate;
		}
	
		public Fabu(String id,String title,String content,int sign,
				String fdate){
			super();
			this.id=id;
			this.title=title;
			this.content=content;
			this.sign=sign;
			this.fdate=fdate;
		}
		
		public Fabu() {
			
		}


}
