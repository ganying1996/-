package com.lvyou.bean;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.lvyou.util.DBConnection;
import com.lvyou.util.DatabaseConnection;



public class User {
	private String id;
	private ResultSet rs;
	private String password;
	private int sum_score;
	private int rel_score;
	private int par_score;
	private String sex;
	
	DatabaseConnection db = new DatabaseConnection();
	Connection conn=null;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}

	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getSum_score() {
		return sum_score;
	}
	public void setSum_score(int sum_score) {
		this.sum_score = sum_score;
	}
	public int getRel_score() {
		return rel_score;
	}
	public void setRel_score(int rel_score) {
		this.rel_score = rel_score;
	}
	public int getPar_score() {
		return par_score;
	}
	public void setPar_score(int par_score) {
		this.par_score = par_score;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	
	public User (String id,String password,String sex,int rel_score,int par_score,int sum_score){
		super();
		this.id =id;
		this.password=password;
		this.sex=sex;
		this.rel_score=rel_score;
		this.par_score=par_score;
		this.sum_score=sum_score;
	}
	public User() {
		
	}
	/*ÓÃ‘ôÔ]ƒÔ*/
	public void register(String id,String password) throws Exception
	{
		this.id=id;
		this.password=password;
		
		/*Connection conn =new DBConn().loadDriver();
		String sql = "insert into user(userName,userPassword,userContact,userAddress) values('"+userName+"','"+password+"','"+userContact+"','"+userAddress+"')";
		Statement stmt =conn.createStatement();
		stmt.executeUpdate(sql);
		stmt.close();*/
		conn = db.getConnection();
		String sql = "insert into user(id,password) values('"+id+"','"+password+"')";
		Statement stmt =conn.createStatement();
		stmt.executeUpdate(sql);
		
		DBConnection.close(stmt);
		DBConnection.close(conn);
	}
	/*ÓÃ‘ôµÇä›*/
	public int logIn(String id, String password)
	{
		
			this.id = id;
			this.password = password;
			int judge = 0;
			conn = db.getConnection();
			String sql = "select password from user where id='"+id+"'";
			try {
			Statement stmt=conn.createStatement();
			rs = stmt.executeQuery(sql);
			
			while(rs.next())
			{
				if(rs.getString(1).equals(password))
				{
					judge = 1;
					System.out.print("µÇÂ¼³É¹¦");
				}
				else
					System.out.print("µÇÂ¼Ê§°Ü");
			//catch (SQLException e) {
				// TODO ×Ô¶¯Éú³ÉµÄ catch ¿é
				//e.printStackTrace();
				
			}
			conn.close();
			stmt.close();
			rs.close();
			}
			catch(SQLException e1){
				// TODO ×Ô¶¯Éú³ÉµÄ catch ¿é
				e1.printStackTrace();
			}
				//db.close();
		 
			
			return judge;
		}
}
	


