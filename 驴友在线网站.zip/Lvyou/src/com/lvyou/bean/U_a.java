package com.lvyou.bean;

public class U_a {
	private String user2_id;
	private int activity1_id;
	private int sign;
	private String fdate;
	
	public String getUser2_id() {
		return user2_id;
	}
	public void setUser2_id(String user2_id) {
		this.user2_id = user2_id;
	}
	public int getActivity1_id() {
		return activity1_id;
	}
	public void setActivity1_id(int activity1_id) {
		this.activity1_id = activity1_id;
	}
	public int getSign() {
		return sign;
	}
	public void setSign(int sign) {
		this.sign = sign;
	}
	public String getFdate() {
		return fdate;
	}
	public void setFdate(String date) {
		this.fdate = date;
	}
	
	

}
