package com.lvyou.servlet;

import java.io.IOException;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lvyou.bean.Activity;
import com.lvyou.bean.Comment;
import com.lvyou.bean.User;
import com.lvyou.daoImpl.ActivityDao;
import com.lvyou.daoImpl.CommentDao;


@WebServlet("/SetComment")
public class CommentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
    public CommentServlet() {
        super();
      
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String act_id = request.getParameter("act_id") ;
		Activity act  = new ActivityDao().findID(act_id);
		int activity2_id = act.getId();
		Format date = new SimpleDateFormat("yyyy.MM.dd");
		String content =request.getParameter("content");
//		//�ж����ĸ��û�����������
//		User user=(User)request.getSession().getAttribute("User");
//		if(user==null){
//			request.setAttribute("error", "Ҫ���۱������ȵ�¼");
//			request.getRequestDispatcher("/activity.jsp").forward(request, response);
////			dispatcher = servletContext.
////					getRequestDispatcher("/fabu.jsp");//��ת��Ϣ����ҳ��
//		}else{
		Comment comment = new Comment();
		comment.setActivity_id(activity2_id);
		comment.setUser1_id("1");
		comment.setDate(date.format(new Date()));
		comment.setContent(content);
		comment.setStatus(0);
		CommentDao commentDao = new CommentDao();
		commentDao.setComment(comment);
		System.out.println(activity2_id);
		System.out.println(date);
		System.out.println(content);
//		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
