package com.lvyou.servlet;

import java.io.IOException;  
import java.util.ArrayList;  
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;  
import javax.servlet.annotation.WebServlet;  
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import com.lvyou.bean.User;  
/** 
 * Servlet implementation class LoginServlet 
 */  
@WebServlet("/LoginServlet")  
public class LoginServlet extends HttpServlet {  
    private static final long serialVersionUID = 1L;        
    /** 
     * @see HttpServlet#HttpServlet() 
     */  
    public LoginServlet() {  
        super();  
        // TODO Auto-generated constructor stub  
    }  
  
    /** 
     * @param id 
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response) 
     */  
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {  
    	request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		response.setCharacterEncoding("UTF-8");
		String action = request.getParameter("action");
		String id = request.getParameter("userId").trim();
		String password = request.getParameter("userpassword").trim();
		User user = new User();
		RequestDispatcher view;
		/*̎����¼Ո��*/
		if(action.equals("��¼"))
		{
			int judge = 0;
			judge = user.logIn(id, password);
			System.out.print(judge);
			if(judge==1)
			{
				
				HttpSession session = request.getSession();
				session.setAttribute("User", user);
				view = request.getRequestDispatcher("Mypage.jsp");
				view.forward(request, response);
			}
			else
			{
				view = request.getRequestDispatcher("tip.jsp");
				view.forward(request, response);
			}
		} 
		}


  
    /** 
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response) 
     */  
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {  
      doGet(request, response);  
    }
    

  
}