package com.lvyou.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
/**
 * ҳ��Ķ�ʱ����ת
 */
 
@WebServlet("/RefreshServlet")
public class RefreshServlet extends HttpServlet {
        
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // ���������
        System.out.println("Refresh1Servletִ����...");
        // ����ͷ��Ϣ
        response.setHeader("refresh", "5;url=url=/Web_01/main.html");
        // ���һ������
        response.getWriter().print("5 miao hou tiao zhuan");
    }
 
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
 
}