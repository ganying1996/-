package com.lvyou.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lvyou.daoImpl.ActivityDao;
import com.lvyou.daoImpl.CommentDao;



@WebServlet("/listAllActivity")
public class ActivityServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ActivityServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		ActivityDao act = new ActivityDao();
		CommentDao comment = new CommentDao();
		if(act.findID(id)!=null) {
			request.setAttribute("activity", act.findID(id));
			request.setAttribute("comment", comment.find(id));
			request.getRequestDispatcher("/activity.jsp").forward(request, response);
		}
		else
			request.getRequestDispatcher("/text.jsp").forward(request, response);
		
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			doGet(request,response);
	}

}
