package com.lvyou.servlet;

import java.io.IOException;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lvyou.bean.News;
import com.lvyou.dao.NewsDAO;
import com.lvyou.daoImpl.NewsDAOImpl;

/**
 * Servlet implementation class NewsPublish
 */
@WebServlet("/NewsPublish")
public class NewsPublish extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public NewsPublish() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8");			//���ò�������
		response.setContentType("text/html;charset=UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		String title=request.getParameter("Title");	//��ȡ�û��������
		String content=request.getParameter("textarea");//��ȡ�û����빫������
		Format format = new SimpleDateFormat("yyyy.MM.dd");	//��ȡϵͳʱ��
		
		ServletContext servletContext = getServletContext();
		RequestDispatcher dispatcher = null;			//����һ��ת������
		
		//Admin admin=(Admin)request.getSession().getAttribute("admin");
		News news=new News();							//ʵ����������
		news.setTitle(title);							//���ù������
		news.setAdmin_id("gabd");				//���÷���������
		news.setContent(content);						//���ù�������
		news.setDate(format.format(new Date()));						//���÷���ʱ��
		
		NewsDAO newsDAO=new NewsDAOImpl();				//��ȡNewsDAOʵ��
		newsDAO.addNews(news);							//���ӹ���
		
		dispatcher = servletContext.getRequestDispatcher("/index.jsp");	//��ת����ҳ
		dispatcher.forward(request, response);			//����ҳ����ת
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
