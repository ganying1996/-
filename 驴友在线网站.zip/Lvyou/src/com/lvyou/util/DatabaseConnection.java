package com.lvyou.util;  
  
import java.sql.Connection;  
import java.sql.DriverManager;
import java.sql.SQLException;

import com.lvyou.bean.User;

import com.mysql.jdbc.Statement;  
public class DatabaseConnection {  
    //�������ݿ���������  
    private static final String DBDRIVER="com.mysql.jdbc.Driver";  
    //���ݿ����ӵ�ַ  
    private static final String DBURL="jdbc:mysql://localhost:3306/webdatabase";//example��ʾ���ݿ�  
    private static final String DBUSER="root";  
    private static final String DBPASS="lvyou";  
    private Connection connection=null;  
    public DatabaseConnection(){  
          
            //���ݿ�������ܳ����쳣  
            try {
				Class.forName(DBDRIVER);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}  
            try {
				connection=DriverManager.getConnection(DBURL,DBUSER,DBPASS);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}  
              
        
            
    }  
    public Connection getConnection(){  
        return connection;  
    }  
    public void close() throws Exception{  
        if(connection!=null){  
            try {  
                connection.close();           
            } catch (Exception e) {  
                throw e;  
            }  
        }  
          
    }  
  

  
}  