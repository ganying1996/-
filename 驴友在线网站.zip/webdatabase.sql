/*
Navicat MySQL Data Transfer

Source Server         : lvyou
Source Server Version : 50720
Source Host           : localhost:3306
Source Database       : webdatabase

Target Server Type    : MYSQL
Target Server Version : 50720
File Encoding         : 65001

Date: 2018-01-14 10:19:01
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `activity`
-- ----------------------------
DROP TABLE IF EXISTS `activity`;
CREATE TABLE `activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_Id` varchar(20) NOT NULL,
  `tel` varchar(20) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `place` varchar(255) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `act_heat` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_Id` (`user_Id`),
  CONSTRAINT `user_Id` FOREIGN KEY (`user_Id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of activity
-- ----------------------------
INSERT INTO `activity` VALUES ('1', 'dshd', '18320124589', '2月18日以后去越南自助游', '2018.02.19', '芽庄|河内', '准备从南宁坐火车去凭祥，凭祥呆一晚，从友谊关出关，到河内、再飞到芽庄。有时间的话可以再去美 奈，不穷游，也不富有。我是80后女吃货一枚，对住宿要求干净卫生。 要求对方最好会英语，因为我的英语 不好', '10');
INSERT INTO `activity` VALUES ('2', 'gy', '12364', '寒假一起去北京玩吧', '2017.3.5', '北京', '本人90后妹子，坐标上海，求2月份结伴，国内旅游，想去云南，哈尔滨或者其他地方，具体行程未定，可商量', '10');
INSERT INTO `activity` VALUES ('3', '1', '4878', '2月份过春节出去玩', '2018.1.9', '上海', '目前暂定计划如下：2.16 上海-海参崴-伊尔库茨克；2.17 伊尔库茨克 2.18-2.21 奥尔洪岛 2.22-', '5');
INSERT INTO `activity` VALUES ('4', '789', '789998', '2018年春节去贝加尔湖看蓝冰！', '2018.6.4', '贝加尔湖', '本人85后女生，自由行经验丰富，去过前苏联多个国家，曾经单独出行多次，大冬天的去西伯利亚想找人结伴', '11');
INSERT INTO `activity` VALUES ('5', 'gy', '1554879', '2018 春节 贝加尔湖/伊尔库茨克', '2018.2.15', '伊尔库茨克', '○人员：已有两位少女，独自出行经验丰富，非常靠谱，好说话，不拖沓，爱吃爱喝爱玩耍；\r\n○招募：希望你是可爱、漂亮又帅气、不嫌麻烦、热爱生活的小伙伴，让我们一起大冬天的去冻冰', '22');
INSERT INTO `activity` VALUES ('6', 'gy', '114131', '上海出发2018年1月中旬岘港', '2018.3.1', '越南', '坐标上海，90年女，计划2018年1月中旬去岘港，', '15');
INSERT INTO `activity` VALUES ('7', 'cnvdj', '589974', '2018春节成都色达小环线自驾游', '2018.2.5', '色达', '成都出发，目的地色达！计划时间是大年初二 2月17号从成都出发，25号成都返程。 自驾川西小环线，', '3');
INSERT INTO `activity` VALUES ('8', '333', '15520365478', '2018跨年行，开启一段意义“菲”凡的旅程吧', '2018.02.15', '香港|菲律宾', '机票已出，大致路线如下。预算除去来回机票，大概3000元。提倡用最经济的方式旅行。\r\n希望有喜欢摄影的小伙伴加入。对路线感兴趣的伙伴微信我把。', '17');
INSERT INTO `activity` VALUES ('14', 'gy', '12365479', '2018年一起去吉安打朱彬亮', '2017.2.6', '吉安', '<p>朱彬亮就是臭傻逼。他就是欠打。我们一起去打他吧！</p>\r\n', '17');
INSERT INTO `activity` VALUES ('15', 'asdh', '18379834320', '2018我们旗开得胜，大吉大利', '2017.2.6', '成都', '本人北京姑娘 自由行经验丰富 30多页的攻略已经做好 不用你操心 如果约玩 我只需要你有一个技能 摄影技术好！我的摄影技术很好', '9');
INSERT INTO `activity` VALUES ('16', 'gy', '17740586985', '新西兰南岛自驾+瓦努阿图火山+斐济鲨鱼共舞', '20180110', '斐济|瓦努阿图|新西兰', '<p>22日登入基督城，开始自驾南岛之旅预计10天左右<br />\r\n随后基督城直飞楠迪，主要目的是鲨鱼潜。<br />\r\n然后飞瓦努阿图，在坦纳岛上有世界上唯一不停喷发的火山。</p>\r\n', '7');
INSERT INTO `activity` VALUES ('17', 'gy', '69874554', '1.20-27北海道约伴', '2018.01.10', '小樽|札幌|日本|北海道', '1.20-27 北海道 机酒已出 五年签 全程住札幌JR站 去札幌 小樽 美瑛 富良野 洞爷湖 函馆 ', '4');
INSERT INTO `activity` VALUES ('18', 'cnvdj', '阿斯蒂芬', '苟富贵', '2018.01.11', '安抚', '<p>的说法</p>\r\n', '23');
INSERT INTO `activity` VALUES ('20', 'gy', '3652488', '今天是课设的最后一天', '2018.01.11', '南昌', '<p>我们在做最后的完善、整合工作！</p>\r\n', '47');
INSERT INTO `activity` VALUES ('28', 'asdh', '17365894788', '春节印度结伴', '2018.02.10', '新德里', '妹子一枚，约1-3个女生拼房拼车，本人穷游，一般出行没计划，已瞎逛为主，\r\n第一次去印度，机票已出德里往返', '24');
INSERT INTO `activity` VALUES ('29', '333', '123456', '今天是课设答辩', '2018.01.12', '南昌', '<p>我们是第一组答辩</p>\r\n', null);

-- ----------------------------
-- Table structure for `admin`
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` varchar(20) NOT NULL,
  `password` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES ('gabd', '5456');

-- ----------------------------
-- Table structure for `answer`
-- ----------------------------
DROP TABLE IF EXISTS `answer`;
CREATE TABLE `answer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `com_Id` int(11) NOT NULL,
  `user3_Id` varchar(20) NOT NULL,
  `activity2_Id` int(11) NOT NULL,
  `content` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `activity2_Id` (`activity2_Id`),
  KEY `user3_Id` (`user3_Id`),
  KEY `com_Id` (`com_Id`),
  CONSTRAINT `activity2_Id` FOREIGN KEY (`activity2_Id`) REFERENCES `activity` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `com_Id` FOREIGN KEY (`com_Id`) REFERENCES `comment` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user3_Id` FOREIGN KEY (`user3_Id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of answer
-- ----------------------------

-- ----------------------------
-- Table structure for `comment`
-- ----------------------------
DROP TABLE IF EXISTS `comment`;
CREATE TABLE `comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `activity_id` int(11) NOT NULL,
  `user1_id` varchar(20) NOT NULL,
  `date` varchar(255) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `status` int(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `activity_id` (`activity_id`),
  KEY `user1_id` (`user1_id`),
  CONSTRAINT `activity_id` FOREIGN KEY (`activity_id`) REFERENCES `activity` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user1_id` FOREIGN KEY (`user1_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of comment
-- ----------------------------
INSERT INTO `comment` VALUES ('7', '20', '1', '2018.01.11', '呵男人！', '0');
INSERT INTO `comment` VALUES ('8', '20', '1', '2018.01.11', '呵女人', '0');
INSERT INTO `comment` VALUES ('9', '20', '1', '2018.01.11', '老师，我想过年', '0');
INSERT INTO `comment` VALUES ('10', '20', '1', '2018.01.11', '这是评论', '0');
INSERT INTO `comment` VALUES ('11', '20', '1', '2018.01.11', '刷客户达大多', '0');
INSERT INTO `comment` VALUES ('12', '18', '1', '2018.01.11', '测试评论', '0');
INSERT INTO `comment` VALUES ('13', '29', '1', '2018.01.12', '我是回复', '0');

-- ----------------------------
-- Table structure for `news`
-- ----------------------------
DROP TABLE IF EXISTS `news`;
CREATE TABLE `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_Id` varchar(20) NOT NULL,
  `date` varchar(255) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_Id` (`admin_Id`),
  CONSTRAINT `admin_Id` FOREIGN KEY (`admin_Id`) REFERENCES `admin` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of news
-- ----------------------------
INSERT INTO `news` VALUES ('1', 'gabd', '2017.5.7', '1、QQ群管理员是义务性质。 \r\n2、QQ群管理员必须每天在线时间不低于5个小时。 \r\n3、QQ群管理员必须踢除群内乱发广告、色情违法信息者和长期不发言者。 \r\n4、QQ群管理员要以身作则，不得在群内发布不允许的信息。 \r\n5、QQ群管理员要负责接待欢迎新成员的加入。 \r\n6、QQ群管理员要传达相关网站管理员的活动召集、网站公告信息到Q群。 ', 'QQ群管理员义务');
INSERT INTO `news` VALUES ('2', 'gabd', '2017.1.5', '三打哈后可见爱神的箭合法化的深V双方都难看', '还是得');
INSERT INTO `news` VALUES ('4', 'gabd', '2018.01.10', '<p>今天我们很开心能来到这里欢聚一堂。有谁打死都不舍得据悉及你是复读机那几款你师父对手</p>\r\n', '这里是测试公告');
INSERT INTO `news` VALUES ('5', 'gabd', '2018.01.10', '<p>我喜欢你，朱彬亮！</p>\r\n', '朱彬亮是大傻瓜');
INSERT INTO `news` VALUES ('6', 'gabd', '2018.01.11', '<p>我们的系统做的不仅不好，功能还不变完善，希望老师能给一个过年的分数！</p>\r\n', '今天是课设最后一天哈');
INSERT INTO `news` VALUES ('7', 'gabd', '2018.01.12', '', '这是公告测试');

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` varchar(20) NOT NULL,
  `password` varchar(20) DEFAULT NULL,
  `sex` varchar(10) DEFAULT NULL,
  `rel_Score` int(11) DEFAULT NULL,
  `par_Score` int(11) DEFAULT NULL,
  `sum_Score` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', '1', '1', '11', '1', '1');
INSERT INTO `user` VALUES ('333', '123', '男', '70', '7', '46');
INSERT INTO `user` VALUES ('789', '123', '女', '56', '18', '50');
INSERT INTO `user` VALUES ('888', '123', null, null, null, null);
INSERT INTO `user` VALUES ('asdh', '79952', 'man', '40', '6', '12');
INSERT INTO `user` VALUES ('cnvdj', '487', 'woman', '42', '10', '18');
INSERT INTO `user` VALUES ('dshd', '4987', 'woman', '41', '8', '15');
INSERT INTO `user` VALUES ('gy', '1234', 'man', '44', '13', '23');
INSERT INTO `user` VALUES ('srrrew', '7789', 'man', '47', '10', '23');

-- ----------------------------
-- Table structure for `u_a`
-- ----------------------------
DROP TABLE IF EXISTS `u_a`;
CREATE TABLE `u_a` (
  `user2_Id` varchar(20) NOT NULL,
  `activity1_Id` int(11) NOT NULL,
  `sign` int(4) DEFAULT NULL,
  `fdate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user2_Id`,`activity1_Id`),
  KEY `activity1_Id` (`activity1_Id`),
  CONSTRAINT `activity1_Id` FOREIGN KEY (`activity1_Id`) REFERENCES `activity` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user2_Id` FOREIGN KEY (`user2_Id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of u_a
-- ----------------------------
INSERT INTO `u_a` VALUES ('cnvdj', '5', '0', '2018.03.05');
INSERT INTO `u_a` VALUES ('gy', '3', '1', '2018.02.05');
INSERT INTO `u_a` VALUES ('gy', '7', '1', '2018.01.11');

-- ----------------------------
-- View structure for `fabu`
-- ----------------------------
DROP VIEW IF EXISTS `fabu`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `fabu` AS select `user`.`id` AS `id`,`activity`.`title` AS `title`,`activity`.`content` AS `content`,`u_a`.`sign` AS `sign`,`u_a`.`fdate` AS `fdate` from ((`user` join `u_a`) join `activity`) where ((`user`.`id` = `u_a`.`user2_Id`) and (`activity`.`id` = `u_a`.`activity1_Id`)) ;
